# 🗺️ Topology Description & GNS3 Connection Guide

## Physical Connections in GNS3

```
┌─────────────────────────────────────────────────────────┐
│                    CORE-ISP-R                           │
│                   (1.1.1.1)                             │
│  Fa0/0    Fa0/1    Fa1/0    Fa1/1    Fa2/0    Fa2/1   │
└────┬────────┬────────┬────────┬────────┬────────┬───────┘
     │        │        │        │        │        │
  BANK-R  SCHOOL-R  HOSP-R  HOME1-R HOME2-R HOME3-R
 Fa0/0   Fa0/0    Fa0/0   Fa0/0   Fa0/0   Fa0/0
     │        │        │        │        │        │
  BANK-SW SCHOOL-SW HOSP-SW HOME1-SW HOME2-SW HOME3-SW
```

## Cable Connections Table

| From Device | Interface | To Device | Interface |
|---|---|---|---|
| CORE-ISP-R | Fa0/0 | BANK-R | Fa0/0 |
| CORE-ISP-R | Fa0/1 | SCHOOL-R | Fa0/0 |
| CORE-ISP-R | Fa1/0 | HOSP-R | Fa0/0 |
| CORE-ISP-R | Fa1/1 | HOME1-R | Fa0/0 |
| CORE-ISP-R | Fa2/0 | HOME2-R | Fa0/0 |
| CORE-ISP-R | Fa2/1 | HOME3-R | Fa0/0 |
| BANK-R | Fa0/1 | BANK-SW | Fa0/1 |
| SCHOOL-R | Fa0/1 | SCHOOL-SW | Fa0/1 |
| HOSP-R | Fa0/1 | HOSP-SW | Fa0/1 |
| HOME1-R | Fa0/1 | HOME1-SW | Fa0/1 |
| HOME2-R | Fa0/1 | HOME2-SW | Fa0/1 |
| HOME3-R | Fa0/1 | HOME3-SW | Fa0/1 |

---

## GNS3 Device Setup

### Routers (Cisco 7200)
- **IOS Image**: c7200-adventerprisek9-mz (or similar)
- **RAM**: 256MB per router
- **Slots needed**:
  - CORE-ISP-R: needs 3 x PA-FE (6 FastEthernet ports)
  - All other routers: 1 x PA-FE (2 FastEthernet ports)
- **Idle PC**: Set for each router to reduce CPU load

### Switches
- Use **GNS3 built-in Ethernet Switch** (no IOS needed)
- OR use **Cisco IOSvL2** if VLAN trunking is required

> ⚠️ **Important**: GNS3 built-in switches don't support VLANs natively.
> For VLAN support use: Cisco IOSvL2 or EtherSwitch module on 7200.

---

## VPN Tunnel Summary

| Tunnel | From | To | Key |
|---|---|---|---|
| VPN-1 | BANK-R (10.0.1.2) | HOSP-R (10.0.3.2) | VPN@Bank#Hosp |

---

## Verification Checklist

After loading all configs, verify in this order:

### Step 1 — Basic Connectivity
```
CORE-ISP-R# ping 10.0.1.2        ! Bank WAN
CORE-ISP-R# ping 10.0.2.2        ! School WAN
CORE-ISP-R# ping 10.0.3.2        ! Hospital WAN
```

### Step 2 — OSPF Neighbors
```
BANK-R# show ip ospf neighbor
BANK-R# show ip route ospf
```

### Step 3 — LAN DHCP
```
! On a PC connected to switch, verify it gets IP
BANK-R# show ip dhcp binding
```

### Step 4 — NAT
```
BANK-R# show ip nat translations
! Generate traffic first: PC > ping 8.8.8.8
```

### Step 5 — VPN
```
BANK-R# show crypto isakmp sa
BANK-R# show crypto ipsec sa
! Trigger with: ping 192.168.30.1 source 192.168.10.65
```

### Step 6 — ACL
```
BANK-R# show access-lists
! Test: try pinging Bank server from Guest VLAN — should fail
```

### Step 7 — Inter-site Routing
```
HOME1-R# ping 192.168.20.1        ! School gateway
HOME1-R# ping 192.168.30.1        ! Hospital gateway
HOME1-R# ping 192.168.10.65       ! Bank staff
```
