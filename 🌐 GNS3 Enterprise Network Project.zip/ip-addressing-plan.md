# 📋 IP Addressing Plan

## WAN Links (Point-to-Point /30 subnets)

| Link | Network | Core-ISP | Site Router |
|---|---|---|---|
| ISP ↔ Bank | 10.0.1.0/30 | 10.0.1.1 | 10.0.1.2 |
| ISP ↔ School | 10.0.2.0/30 | 10.0.2.1 | 10.0.2.2 |
| ISP ↔ Hospital | 10.0.3.0/30 | 10.0.3.1 | 10.0.3.2 |
| ISP ↔ Home1 | 10.0.4.0/30 | 10.0.4.1 | 10.0.4.2 |
| ISP ↔ Home2 | 10.0.5.0/30 | 10.0.5.1 | 10.0.5.2 |
| ISP ↔ Home3 | 10.0.6.0/30 | 10.0.6.1 | 10.0.6.2 |

---

## Loopback Interfaces (Router IDs for OSPF)

| Router | Loopback IP |
|---|---|
| CORE-ISP-R | 1.1.1.1/32 |
| BANK-R | 2.2.2.2/32 |
| SCHOOL-R | 3.3.3.3/32 |
| HOSP-R | 4.4.4.4/32 |
| HOME1-R | 5.5.5.5/32 |
| HOME2-R | 6.6.6.6/32 |
| HOME3-R | 7.7.7.7/32 |

---

## LAN Networks (Internal per site)

### 🏦 Bank — 192.168.10.0/24
| VLAN | Name | Subnet | Gateway | DHCP Range |
|---|---|---|---|---|
| VLAN 10 | Management | 192.168.10.0/26 | 192.168.10.1 | .10 – .62 |
| VLAN 20 | Staff | 192.168.10.64/26 | 192.168.10.65 | .70 – .126 |
| VLAN 30 | ATM/Servers | 192.168.10.128/26 | 192.168.10.129 | Static only |
| VLAN 40 | Guest/CCTV | 192.168.10.192/26 | 192.168.10.193 | .200 – .254 |

### 🏫 School — 192.168.20.0/24
| VLAN | Name | Subnet | Gateway | DHCP Range |
|---|---|---|---|---|
| VLAN 10 | Admin | 192.168.20.0/26 | 192.168.20.1 | .10 – .62 |
| VLAN 20 | Teachers | 192.168.20.64/26 | 192.168.20.65 | .70 – .126 |
| VLAN 30 | Students | 192.168.20.128/26 | 192.168.20.129 | .140 – .190 |
| VLAN 40 | Labs | 192.168.20.192/26 | 192.168.20.193 | .200 – .254 |

### 🏥 Hospital — 192.168.30.0/24
| VLAN | Name | Subnet | Gateway | DHCP Range |
|---|---|---|---|---|
| VLAN 10 | Admin | 192.168.30.0/26 | 192.168.30.1 | .10 – .62 |
| VLAN 20 | Doctors/Staff | 192.168.30.64/26 | 192.168.30.65 | .70 – .126 |
| VLAN 30 | Medical Devices | 192.168.30.128/26 | 192.168.30.129 | Static only |
| VLAN 40 | Patients WiFi | 192.168.30.192/26 | 192.168.30.193 | .200 – .254 |

### 🏠 Home 1 — 192.168.40.0/24
| Subnet | Gateway | DHCP Range |
|---|---|---|
| 192.168.40.0/24 | 192.168.40.1 | .10 – .100 |

### 🏠 Home 2 — 192.168.50.0/24
| Subnet | Gateway | DHCP Range |
|---|---|---|
| 192.168.50.0/24 | 192.168.50.1 | .10 – .100 |

### 🏠 Home 3 — 192.168.60.0/24
| Subnet | Gateway | DHCP Range |
|---|---|---|
| 192.168.60.0/24 | 192.168.60.1 | .10 – .100 |

---

## NAT Pool (Simulated Public IPs)

| Site | Inside (LAN) | Outside (Simulated Public) |
|---|---|---|
| Bank | 192.168.10.0/24 | 203.0.113.10 |
| School | 192.168.20.0/24 | 203.0.113.20 |
| Hospital | 192.168.30.0/24 | 203.0.113.30 |
| Home1 | 192.168.40.0/24 | 203.0.113.40 |
| Home2 | 192.168.50.0/24 | 203.0.113.50 |
| Home3 | 192.168.60.0/24 | 203.0.113.60 |
